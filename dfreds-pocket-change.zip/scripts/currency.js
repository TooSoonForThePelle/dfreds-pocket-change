import Settings from './settings.js';

export default class Currency {
  /**
   * Creates a new currency class
   *
   * @param {Actor} actor - The actor used to initialize the currency
   */
  constructor(actor) {
    this._settings = new Settings();

    this._cp = actor.system?.currency?.cp?.value || 0;
    this._sp = actor.system?.currency?.cp?.value || 0;
    this._ep = actor.system?.currency?.cp?.value || 0;
    this._gp = actor.system?.currency?.cp?.value || 0;
    this._pp = actor.system?.currency?.cp?.value || 0;
  }

  /**
   * Adds copper to the currency object
   *
   * @param {number} amount - The amount of copper to add
   */
  addCopper(amount) {
    this._cp += Math.floor(amount * this._settings.currencyMultiplier);
  }

  /**
   * Adds silver to the currency object
   *
   * @param {number} amount - The amount of silver to add
   */
  addSilver(amount) {
    this._sp += Math.floor(amount * this._settings.currencyMultiplier);
  }

  /**
   * Adds electrum to the currency object
   *
   * @param {number} amount - The amount of electrum to add
   */
  addElectrum(amount) {
    this._ep += Math.floor(amount * this._settings.currencyMultiplier);
  }

  /**
   * Adds gold to the currency object
   *
   * @param {number} amount - The amount of gold to add
   */
  addGold(amount) {
    this._gp += Math.floor(amount * this._settings.currencyMultiplier);
  }

  /**
   * Adds platinum to the currency object
   *
   * @param {number} amount - The amount of platinum to add
   */
  addPlatinum(amount) {
    this._pp += Math.floor(amount * this._settings.currencyMultiplier);
  }

  /**
   * Converts currencies down a type if they are not enabled in the settings.
   *
   * Example: Platinum converts to gold converts to electrum if both platinum
   * and gold are disabled.
   */
  convertCurrencies() {
    if (!this._settings.usePlatinum) {
      this._convertPlatinumToGold();
    }

    if (!this._settings.useGold) {
      this._convertGoldToElectrum();
    }

    if (!this._settings.useElectrum) {
      this._convertElectrumToSilver();
    }

    if (!this._settings.useSilver) {
      this._convertSilverToCopper();
    }
  }

  _convertPlatinumToGold() {
    this._gp += this._pp * 10;
    this._pp = 0;
  }

  _convertGoldToElectrum() {
    this._ep += this._gp * 2;
    this._gp = 0;
  }

  _convertElectrumToSilver() {
    this._sp += this._ep * 5;
    this._ep = 0;
  }

  _convertSilverToCopper() {
    this._cp += this._sp * 10;
    this._sp = 0;
  }

  /**
   * Converts the currency data to the standard format for an Actor sheet
   *
   * @returns {Object} An object containing the currencies
   */
  convertToStandardCurrency() {
    return {
      cp: this._cp,
      sp: this._sp,
      ep: this._ep,
      gp: this._gp,
      pp: this._pp,
    };
  }
}
